# R Code for Exploration and Analysis of UCI Bicycle Rental Data using Azure Machine Learning and R

This repository contains the R code for the exploration and analysis of the [UCI Bicycle Rental data](https://archive.ics.uci.edu/ml/datasets/Bike+Sharing+Dataset) with [Microsoft Azure Machine Learning](https://archive.ics.uci.edu/ml/datasets/Bike+Sharing+Dataset) and R. 